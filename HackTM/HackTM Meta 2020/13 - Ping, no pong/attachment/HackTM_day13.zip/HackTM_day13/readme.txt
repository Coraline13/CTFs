1. The folder "example" contains a test movie "test.mp4". 
   The solution to "test.mp4" is: "1010100 1100101 1110011 1110100 1000000000000 0000000 0000000 0000000 0000000 0000000 0000000 0000000 0000000 0000000 0000000 0000000 0000000 0000000 0000000 0000000 0000000 0000000 0000000 0000000 0000000 0000000 0000000" which translates to "Test ".

2. The folder "day13" contains your input movie "output.mkv".

3. The trainig set can be found at: https://drive.google.com/drive/folders/1Ll-VpyPLyXdT-Vun8UlCsm5ypWYKLYkb?usp=sharing 
   It contains images with hidden messages.

4. The original dataset can be found at: http://images.cocodataset.org/zips/train2017.zip
   It contains clean images (no hidden data).