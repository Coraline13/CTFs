var _0xe154 = [
    '\x63\x68\x61\x72\x43\x6f\x64\x65\x41\x74',
    '\x69\x6e\x64\x65\x78\x4f\x66',
    '\x6c\x65\x6e\x67\x74\x68'
];
(function (_0x1655db, _0xe15424) {
    var _0x53b6f2 = function (_0x475b41) {
        while (--_0x475b41) {
            _0x1655db['push'](_0x1655db['shift']());
        }
    };
    _0x53b6f2(++_0xe15424);
}(_0xe154, 0xc1));
var _0x53b6 = function (_0x1655db, _0xe15424) {
    _0x1655db = _0x1655db - 0x0;
    var _0x53b6f2 = _0xe154[_0x1655db];
    return _0x53b6f2;
};
function do_checksum(_0x577509) {
    var _0x5b482f = _0x577509[_0x53b6('\x30\x78\x30')]('\x7b');
    var _0x49417d = _0x577509['\x69\x6e\x64\x65\x78\x4f\x66']('\x7d');
    if (_0x5b482f == -0x1 || _0x49417d == -0x1) {
        return 0x0;
    } else {
        var _0x207510 = _0x577509['\x73\x75\x62\x73\x74\x72\x69\x6e\x67'](_0x5b482f + 0x1, _0x49417d);
        var _0x1831b0 = 0x0;
        for (var _0x365460 = 0x0; _0x365460 < _0x207510[_0x53b6('\x30\x78\x31')]; _0x365460++) {
            _0x1831b0 += _0x207510[_0x365460][_0x53b6('\x30\x78\x32')](0x0);
        }
        if (_0x1831b0 != 0x4c8) {
            return 0x0;
        } else {
            return 0x1;
        }
    }
}
function isDigit(_0x3d2130) {
    if (_0x3d2130 >= '\x30' && _0x3d2130 <= '\x39') {
        return 0x1;
    } else {
        return 0x0;
    }
}
function check_input(_0x59430b) {
    if (_0x59430b[0x0] == '\x48' && _0x59430b[0x1] == '\x61' && _0x59430b[0x2] == '\x63' && _0x59430b[0x3] == '\x6b' && _0x59430b[0x4] == '\x54' && _0x59430b[0x5] == '\x4d' && _0x59430b[0x6] == '\x7b' && _0x59430b[_0x59430b[_0x53b6('\x30\x78\x31')] - 0x1] == '\x7d') {
        if (_0x59430b[_0x59430b[_0x53b6('\x30\x78\x31')] - 0x2] == _0x59430b[_0x59430b[_0x53b6('\x30\x78\x31')] - 0x3] && _0x59430b[_0x59430b[_0x53b6('\x30\x78\x31')] - 0x3] == _0x59430b[_0x59430b['\x6c\x65\x6e\x67\x74\x68'] - 0x4] && _0x59430b[_0x59430b['\x6c\x65\x6e\x67\x74\x68'] - 0x4] == _0x59430b[_0x59430b[_0x53b6('\x30\x78\x31')] - 0x2]) {
            if (_0x59430b[_0x59430b['\x6c\x65\x6e\x67\x74\x68'] - 0x2][_0x53b6('\x30\x78\x32')](0x0) != 0x63 / 0x3) {
                return 0x0;
            }
            if (_0x59430b['\x6c\x65\x6e\x67\x74\x68'] != 0x18) {
                return 0x0;
            }
            if (do_checksum(_0x59430b)) {
                var _0x149c50 = _0x59430b[_0x53b6('\x30\x78\x30')]('\x7b');
                var _0xa545cc = _0x59430b[_0x53b6('\x30\x78\x30')]('\x21');
                var _0x44b53a = _0x59430b['\x73\x75\x62\x73\x74\x72\x69\x6e\x67'](_0x149c50 + 0x1, _0xa545cc);
                if (_0x44b53a[0xa] != _0x44b53a[0xc]) {
                    return 0x0;
                }
                if (!(isDigit(_0x44b53a[0x1]) && isDigit(_0x44b53a[0x4]) && isDigit(_0x44b53a[0x7]) && isDigit(_0x44b53a[0xa]) && isDigit(_0x44b53a[0xc]))) {
                    return 0x0;
                }
                if (_0x44b53a[0x5] != '\x5f' || _0x44b53a[0x8] != '\x5f') {
                    return 0x0;
                }
                if ((_0x44b53a[0x0][_0x53b6('\x30\x78\x32')](0x0) ^ 0x58) != 0x28 || _0x44b53a[0x2] != _0x44b53a[0x3] || (_0x44b53a[0x3]['\x63\x68\x61\x72\x43\x6f\x64\x65\x41\x74'](0x0) ^ 0x58) != 0x22) {
                    return 0x0;
                }
                if (_0x44b53a[0x6] != '\x69') {
                    return 0x0;
                }
                if (_0x44b53a[0x7] - _0x44b53a[0x4] != _0x44b53a[0x1]) {
                    return 0x0;
                }
                if (_0x44b53a[0xa][_0x53b6('\x30\x78\x32')](0x0) != 0x66 / 0x2) {
                    return 0x0;
                }
                if (_0x44b53a[0xb] + _0x44b53a[0x9] != '\x72\x68') {
                    return 0x0;
                }
                return 0x1;
            } else {
                return 0x0;
            }
        } else {
            return 0x0;
        }
    } else {
        return 0x0;
    }
}